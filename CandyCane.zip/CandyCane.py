import copy
import math
import xml.dom.minidom

#
# The goal of this program is to make an xLigts custom model
#  for a candy cane, that is pretty big and set in 3 sections.
#
# This is just math into coordinates, float coordinates into buffer,
#  Then the fitting of an integer grid.
#
# Making submodels is the next thing.
#  Submodel generation here is extremely specific, it does one per cane,
#    and one for the whole
#
# This particular code does not make the groups for you.  You will have to add the submodels to your groups as you see fit

# I'm working in inches, 1/4" resolution
pspc = 8.0 # pixel spacing of 2" at 1/4" is 8.0
mname = "SALCane"

props = []
propCounts = []
points = []
submodelInstances = {}

#Section 1 (lower)
basex = 0.0
basey = 0.0
stringsl = []
curpt = 1;
for j in range (0, 8):
    stringsl.append([])
    for i in range(0, 26):
        if (j % 2 == 0):
            points.append((pspc*j + basex, pspc*i + basey))
        else:
            points.append((pspc*j + basex, pspc*(25-i) + basey))
        stringsl[j].append(str(curpt))
        curpt = curpt + 1

#Section 2 (middle)
basex = 0.0
basey = 8.0 * 26 # Already did 26
stringsm = []
for j in range (0, 8):
    stringsm.append([])
    for i in range(0, 27):
        if (j % 2 == 0):
            points.append((pspc*j + basex, pspc*i + basey));
        else:
            points.append((pspc*j + basex, pspc*(26-i) + basey));
        stringsm[j].append(str(curpt));
        curpt = curpt + 1;

#Section 3 (middle)
oradius = 70.0 * pspc / 2 / 2 # Assuming there's an inch around it and the diameter was 72
basex = 0.0
basey = pspc * (26+27) # Already did 26+27
cpts = 53 # Points along circumference
sangle = 3.14159 #start angle, -180 from axis
eangle = .05 # Looks like it ends a bit up from horizontal?
stringsu = []
for j in range (0, 8):
    stringsu.append([])
    for i in range (0, cpts):
        if (j%2 == 0):
            angle = (sangle + (eangle - sangle) / (cpts - 1) * i)
        else:
            angle = (sangle + (eangle - sangle) / (cpts - 1) * (cpts - 1 - i))
        radius = oradius - pspc * j
        #print (radius, "@", angle)
        points.append((basex + oradius + radius * math.cos(angle), basey + radius * math.sin(angle)))
        #print (points[-1])
        stringsu[j].append(str(curpt))
        curpt = curpt + 1;

print ('Total Points: ', len(points))

# Now we bound these points to know the grid size
(minx, miny) = points[0]
(maxx, maxy) = points[0]
for p in points: # Pay no attention to the nagging thought that python has a one-liner for this
    (px, py) = p
    minx = min(minx, px)
    miny = min(miny, py)
    maxx = max(maxx, px)
    maxy = max(maxy, py)

w = int(maxx-minx) + 1
h = int(maxy-miny) + 1

# Now we build the grid
data = []
for r in range(h):
    data.append([])
    for c in range(w):
        data[-1].append(-1)

pn = 0
for p in points:
    (x, y) = p
    c = int(x-minx)
    r = int(y-miny)
    pn = pn + 1
    if (data[r][c] != -1):
        print (pn)
        raise("Sorry, 2 pixels in the same grid box, do something different and try again");
    data[r][c] = pn;

#Grid was built upside down, flip it, then emit in xLights form
data.reverse()
dstr = ""
for r in data:
    if (len(dstr)):
        dstr = dstr + ';'
    rstr = ""
    cn = 0
    for c in r:
        if (c >= 0):
            rstr += str(c)
        if (cn < len(r)-1):
            rstr = rstr + ','
        cn = cn + 1
    dstr = dstr + rstr

# Make a new document
od = xml.dom.minidom.Document()
mn = od.createElement("custommodel")
mn.setAttribute("name", mname)
mn.setAttribute('parm1', str(w))
mn.setAttribute('parm2', str(h))
mn.setAttribute('Depth',  "1")
mn.setAttribute('StringType', "RGB Nodes")
mn.setAttribute('Transparency', "0")
mn.setAttribute('PixelSize', "2")
mn.setAttribute('ModelBrightness', "")
mn.setAttribute('Antialias', "1")
#mn.setAttribute('StrandNames', ...)
#mn.setAttribute('NodeNames', ...)
mn.setAttribute('SourceVersion', "2022.11")
mn.setAttribute('CustomModel', dstr)

#Work out submodels
fulllines = []
for j in range (0, 8):
    if (j % 2 == 0):
        pass
    else:
        stringsl[j].reverse()
        stringsm[j].reverse()
        stringsu[j].reverse()
    fulllines.append(stringsl[j][:]+stringsm[j][:]+stringsu[j][:])


# Make a submodel for the whole cane
stn = od.createElement("subModel")
stn.setAttribute('name', 'caneMatrix')
stn.setAttribute('layout', 'horizontal')
stn.setAttribute('type', 'ranges')
stn.setAttribute('bufferstyle', 'default')
for j in range(0, 8):
    stn.setAttribute('line'+str(j), ','.join(fulllines[j]))
mn.appendChild(stn)

# Make a submodel for the single canes
for j in range(0, 8):
    stn = od.createElement("subModel")
    stn.setAttribute('name', 'cane'+str(j))
    stn.setAttribute('layout', 'horizontal')
    stn.setAttribute('type', 'ranges')
    stn.setAttribute('bufferstyle', 'default')
    stn.setAttribute('line0', ','.join(fulllines[j]))
    mn.appendChild(stn)

#for g in groupsByName:
#    grp = groupsByName[g]
#    gn = od.createElement("modelGroup")
#    gn.setAttribute('name', grp.name)
#    gn.setAttribute('layout', grp.layout)
#    gn.setAttribute('LayoutGroup', grp.layoutGroup)
#    gn.setAttribute('GridSize', grp.gridSize)
#    gn.setAttribute('models', ','.join(grp.models))
#    mn.appendChild(gn)

od.appendChild(mn)

# Write output file
with open(mname+".xmodel","w") as outfile:
    od.writexml(outfile)
